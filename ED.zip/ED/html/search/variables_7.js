var searchData=
[
  ['x1',['x1',['../struct_quads.html#aeb625bc212599f122a2f9cacc1508000',1,'Quads::x1()'],['../struct_coordinate.html#a1daf8f4aa3a33e7b14c59e18ce76e1b5',1,'Coordinate::x1()']]],
  ['x2',['x2',['../struct_quads.html#a6dd0ced10c927b5d37d0993cf1001370',1,'Quads']]],
  ['x3',['x3',['../struct_quads.html#a333898c9d62aac6cd984e70083cb8504',1,'Quads']]],
  ['x4',['x4',['../struct_quads.html#a71068bfcd0519dbc99640845714d50b2',1,'Quads']]]
];
