var searchData=
[
  ['t',['t',['../struct_coordinate.html#a306cb327ee1a1d7dad90f8170bf71a29',1,'Coordinate']]],
  ['total',['total',['../struct_quads.html#a06a2ed8a5b8c0fe9097a1ae855b56f62',1,'Quads']]]
];
