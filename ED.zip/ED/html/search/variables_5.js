var searchData=
[
  ['state',['state',['../struct_quads.html#a500ba50eed0d8bf65073d69d51bcb0df',1,'Quads']]]
];
