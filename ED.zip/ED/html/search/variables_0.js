var searchData=
[
  ['b',['b',['../struct_quads.html#aae03e87fb373aa1a3e7bcbfdd4ad17cf',1,'Quads']]]
];
