var searchData=
[
  ['quads',['Quads',['../struct_quads.html',1,'']]]
];
