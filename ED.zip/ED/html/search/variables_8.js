var searchData=
[
  ['y1',['y1',['../struct_quads.html#a69d07905aa5461595aa5f02d15e91793',1,'Quads::y1()'],['../struct_coordinate.html#a3846fb33eb04daa9b0e9c14b17b26b9b',1,'Coordinate::y1()']]],
  ['y2',['y2',['../struct_quads.html#a400a6f0ad3fb8014c7ce9bb1f9a523ad',1,'Quads']]],
  ['y3',['y3',['../struct_quads.html#a3ae01fe424f6afed563bc8bf49668c3b',1,'Quads']]],
  ['y4',['y4',['../struct_quads.html#a50f557d2667d086b4555716f7cf99b14',1,'Quads']]]
];
