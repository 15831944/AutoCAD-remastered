var searchData=
[
  ['points',['points',['../ed_8cpp.html#a753028628746907ce34e775d29331865',1,'ed.cpp']]]
];
