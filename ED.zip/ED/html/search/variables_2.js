var searchData=
[
  ['g',['g',['../struct_quads.html#aa7f7a7d499d9a28e4769d5723518fb15',1,'Quads']]]
];
