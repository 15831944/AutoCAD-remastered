var searchData=
[
  ['r',['r',['../struct_quads.html#a51f77c54ac8cb55f274c99a7a4e8c9ff',1,'Quads']]],
  ['removeduplicate',['removeduplicate',['../ed_8cpp.html#a76e758440b9814f7f8d33632cc2b6969',1,'ed.cpp']]]
];
