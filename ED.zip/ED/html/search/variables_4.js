var searchData=
[
  ['r',['r',['../struct_quads.html#a51f77c54ac8cb55f274c99a7a4e8c9ff',1,'Quads']]]
];
