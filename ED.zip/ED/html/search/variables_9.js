var searchData=
[
  ['z1',['z1',['../struct_quads.html#ad6301a207b7c2fc4b3aff0228ed4cbb5',1,'Quads::z1()'],['../struct_coordinate.html#af9e6fad3ed7ffb48b857771c4ccd2a07',1,'Coordinate::z1()']]],
  ['z2',['z2',['../struct_quads.html#a107840c46b68f73e720b0804a88caaa2',1,'Quads']]],
  ['z3',['z3',['../struct_quads.html#a527151703160c549877fcf5b2fb413ad',1,'Quads']]],
  ['z4',['z4',['../struct_quads.html#ac19b327dae53cc940df43cfd1d9f1af4',1,'Quads']]]
];
