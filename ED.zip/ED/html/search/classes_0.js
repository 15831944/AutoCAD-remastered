var searchData=
[
  ['coordinate',['Coordinate',['../struct_coordinate.html',1,'']]]
];
